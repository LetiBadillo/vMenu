<?php $__env->startSection('content'); ?>
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Catálogo de clientes</h1>
            <br>
            <a class="btn btn-primary" href="<?php echo e(route('clients.create')); ?>"> + Nuevo cliente</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">Nombre</th>
                    <th class="text-center">Apellido</th>
                    <th class="text-center">E-mail</th>
                    <th class="text-center">RFC</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Ciudad</th>
                    <th class="text-center">CP</th>
                    <th class="text-center">Teléfono</th>
                    <th class="text-center" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($clients)): ?>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->last_name); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->rfc); ?></td>
                    <td><?php echo e($client->address); ?></td>
                    <td><?php echo e($client->city); ?></td>
                    <td><?php echo e($client->zipcode); ?></td>
                    <td><?php echo e($client->phone); ?></td>
                    <td><a href="<?php echo e(route('clients.edit', ['id'=>$client['id']])); ?>" class="btn btn-warning">Edit</a></td>
                    <td>
                    <form action="<?php echo e(route('clients.destroy', ['id'=>$client->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="<?php echo e($client->id); ?>">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                    <td class="text-center alert alert-danger" colspan="9">No hay clientes registrados</td>
                    </tr>
                    <?php endif; ?>
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>