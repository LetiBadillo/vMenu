<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Holi</title>

</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
        <br><br>
        <a href="<?php echo e(url('/')); ?>">Home</a>
        </div>
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>