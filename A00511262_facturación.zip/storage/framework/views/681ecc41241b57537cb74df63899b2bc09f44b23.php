<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Detalle</h1>
        <br>
        <p>Cliente: <?php echo e($invoice->client->name); ?></p>
        <p>Fecha: <?php echo e($invoice->created_at); ?></p>
        <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">SKU</th>                    
                    <th class="text-center">Producto</th>
                    <th class="text-center">Cantidad</th>
                    <th class="text-center">Precio</th>
                    <th class="text-center">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                <?php $suma = 0; ?>
                    <?php if($invoice): ?>
                        <?php $__currentLoopData = $invoice->invoice_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($i->product->sku); ?></td>
                        <td><?php echo e($i->product->description); ?></td>
                        <td><?php echo e($i->quantity); ?></td>
                        <td><?php echo e($i->product->price); ?></td>
                        <td>$<?php echo e($i->quantity * $i->product->price); ?></td>
                        <?php  $suma += $i->quantity * $i->product->price ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td colspan="4">Subotal:</td>
                        <td colspan="1">$<?php echo e($suma); ?></td>
                        </tr>
                        <tr>
                        <td colspan="4">IVA:</td>
                        <td colspan="1">$<?php echo e($suma * 0.16); ?></td>
                        </tr>
                        <tr>
                        <td colspan="4">Total:</td>
                        <td colspan="1">$<?php echo e($suma + $suma * 0.16); ?></td>
                        </tr>
                    <?php else: ?>
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay productos registrados</td>
                    </tr>
                    <?php endif; ?>
                
                </tbody>
        </table>
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="<?php echo e(url('invoice')); ?>">Facturas</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>