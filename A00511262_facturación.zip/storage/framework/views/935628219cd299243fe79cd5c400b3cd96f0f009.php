<?php $__env->startSection('content'); ?>
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Catálogo de productos</h1>
            <br>
            <a class="btn btn-primary" href="<?php echo e(route('products.create')); ?>"> + Nuevo producto</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">SKU</th>
                    <th class="text-center">Descripción</th>
                    <th class="text-center">Precio</th>
                    <th class="text-center" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($products)): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($product->sku); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><a href="<?php echo e(route('products.edit', ['id'=>$product['id']])); ?>" class="btn btn-warning">Edit</a></td>
                    <td>
                    <form action="<?php echo e(route('products.destroy', ['id'=>$product->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="<?php echo e($product->id); ?>">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay productos registrados</td>
                    </tr>
                    <?php endif; ?>
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>