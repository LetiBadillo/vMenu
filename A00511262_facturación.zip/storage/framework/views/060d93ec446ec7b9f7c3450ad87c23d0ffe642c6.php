<?php $__env->startSection('content'); ?>
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Facturas</h1>
            <br>
            <a class="btn btn-primary" href="<?php echo e(route('invoice.create')); ?>"> + Nueva factura</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Cliente</th>
                    <th class="text-center">Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($invoices)): ?>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td> <a href="<?php echo e(url('invoice')); ?><?php echo e('/'.$invoice->id); ?>"> <?php echo e($invoice->id); ?> </a></td>
                    <td><?php echo e($invoice->client->name); ?></td>
                    <td><?php echo e($invoice->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay facturas registradas</td>
                    </tr>
                    <?php endif; ?>
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>