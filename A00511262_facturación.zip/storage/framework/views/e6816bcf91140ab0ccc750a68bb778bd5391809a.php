<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Catálogo de clientes</h1>
        <form method="post" action="<?php echo e(route('clients.update', ['id'=>$client->id])); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="_method" value="PUT">
            <label for="name">Nombre:</label>
            <input class="form-control" required type="text" value="<?php echo e($client->name); ?>" name="name" id="">
            <label for="last_name">Apellidos:</label>
            <input class="form-control" required type="text" value="<?php echo e($client->last_name); ?>" name="last_name" id="">
            <label for="street">E-mail:</label>
            <div class="input-group">
				<span class="input-group-addon" id="MoneyAddon"><b>@</b></span>
				</span><input class="form-control" required type="email" value="<?php echo e($client->email); ?>" name="email" id="">
			</div>
            <label for="last_name">RFC:</label>
            <input class="form-control" required type="text" name="rfc" value="<?php echo e($client->rfc); ?>" id="">
            <label for="last_name">Dirección:</label>
            <input class="form-control" required type="text" name="address" value="<?php echo e($client->address); ?>" id="">
            <label for="last_name">Ciudad:</label>
            <input class="form-control" required type="text" name="city" value="<?php echo e($client->city); ?>" id="">
            <label for="last_name">CP:</label>
            <input class="form-control" required type="text" name="zipcode" value="<?php echo e($client->zipcode); ?>"id="">
            <label for="last_name">Teléfono:</label>
            <input class="form-control" required type="text" name="phone" value="<?php echo e($client->phone); ?>" id="">
            <br>
            <input type="submit" class="btn btn-success" name="submit" value="Guardar">
        </form>
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="<?php echo e(url('clients')); ?>">Ver lista de clientes</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>