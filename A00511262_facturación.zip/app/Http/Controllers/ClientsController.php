<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;

class ClientsController extends Controller
{
    //
    public function index(Request $request){
        $clients = Client::all();
        if($request->ws = "all"){
            return $clients;
        }
        
        return view('clients.index', compact('clients'));
    }
    public function create(){
        return view('clients.create');
    }

    public function store(Request $request){
        $client = Client::create($request->all());
        return redirect('clients');
    }

    public function edit(Request $request, $id){
        $client = Client::findOrFail($id);
        return view('clients.edit', compact('client'));
    }
    public function update(Request $request, $id){
        $client = Client::findOrFail($id)->update($request->all());
        return redirect('clients');
    }
    public function show(Request $request, $id){
        $client = Client::findOrFail($id);
    }
    public function destroy($id){
        $client = Client::findOrFail($id)->delete();
        return \Redirect::back();
    }
}
