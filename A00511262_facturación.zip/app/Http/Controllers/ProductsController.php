<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductsController extends Controller
{
    //
    public function index(Request $request){
        $products = Product::all();
        if($request->ws = "all"){
            return $products;
        }
        return view('products.index', compact('products'));
    }
    public function create(){
        return view('products.create');
    }

    public function store(Request $request){
        $product = Product::create($request->all());
        return redirect('products');
    }

    public function edit(Request $request, $id){
        $product = Product::findOrFail($id);
        return view('products.edit', compact('product'));
    }
    public function update(Request $request, $id){
        $product = Product::findOrFail($id)->update($request->all());
        return redirect('products');
    }
    public function show(Request $request, $id){
        $product = Product::findOrFail($id);
    }
    public function destroy($id){
        $product = Product::findOrFail($id)->delete();
        return \Redirect::back();
    }
}
