<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;
use App\InvoiceDetail;

class InvoiceController extends Controller
{
    public function index(){
        $invoices = Invoice::all();
        return view('invoice.index', compact('invoices'));
    }
    public function create(){
        return view('invoice.create');
    }

    public function store(Request $request){
        $invoice = Invoice::create($request->all());
        foreach($request->quantity as $key => $quantity ) {
            InvoiceDetail::create([
                'invoice_id' => $invoice->id, 
                'product_id' => $request->product[$key], 
                'quantity' => $request->quantity[$key]]);
        }
        return redirect('invoice');
    }
    public function update(Request $request, $id){
        $invoice = Invoice::findOrFail($id)->update($request->all());
        return redirect('invoice');
    }
    public function show(Request $request, $id){
        $invoice = Invoice::findOrFail($id);
            
        return view('invoice.show', compact('invoice'));
    }
    public function destroy($id){
        $invoice = Invoice::findOrFail($id)->delete();
        return \Redirect::back();
    }
}
