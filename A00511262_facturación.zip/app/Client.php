<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    //
    protected $fillable = [
        'name', 'last_name', 'email', 'rfc', 'address', 'city', 'zipcode', 'phone'
    ];

    public function invoice(){
        return $this->hasMany('App\Invoice', 'client_id');
    }
    function invoice_detail(){
        return $this->hasManyThrough(InvoiceDetail::class, Invoice::class);
    }
}
