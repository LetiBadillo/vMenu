<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoice extends Model
{
    protected $fillable = ['client_id'];
    protected $table = 'invoice';
    
    public function invoice_detail(){
        return $this->hasMany('App\InvoiceDetail', 'invoice_id');
    }

    public function client(){
        return $this->belongsTo('App\Client', 'client_id');
    }

}
