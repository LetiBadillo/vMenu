@extends('layouts.layout')
@section('content')
    <br><br>
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Catálogo de productos</h1>
            <form method="post" action="{{route('products.update', ['id'=>$product->id])}}">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="PUT">
            <label for="name">SKU:</label>
            <input class="form-control" required type="number" value="{{$product->sku}}" name="sku" id="">
            <label for="last_name">Descripción:</label>
            <input class="form-control" required type="text" name="description" value="{{$product->description}}">
            <label for="street">Precio:</label>
            <div class="input-group">
				<span class="input-group-addon" id="MoneyAddon"><b>$</b></span>
				</span><input class="form-control" value="{{$product->price}}" required type="text" name="price" id="">
			</div>
            <br>
            <input type="submit" class="btn btn-success" name="submit" value="Guardar">
        </form>
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="{{url('products')}}">Ver lista de productos</a>
        </div>
    </div>
@endsection