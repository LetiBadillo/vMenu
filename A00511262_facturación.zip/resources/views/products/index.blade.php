@extends('layouts.layout')
@section('content')
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Catálogo de productos</h1>
            <br>
            <a class="btn btn-primary" href="{{route('products.create')}}"> + Nuevo producto</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">SKU</th>
                    <th class="text-center">Descripción</th>
                    <th class="text-center">Precio</th>
                    <th class="text-center" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($products))
                    @foreach($products as $product)
                    <tr>
                    <td>{{$product->sku}}</td>
                    <td>{{$product->description}}</td>
                    <td>{{$product->price}}</td>
                    <td><a href="{{route('products.edit', ['id'=>$product['id']])}}" class="btn btn-warning">Edit</a></td>
                    <td>
                    <form action="{{route('products.destroy', ['id'=>$product->id])}}" method="post">
                        {{ csrf_field() }}
                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="{{$product->id}}">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    </td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay productos registrados</td>
                    </tr>
                    @endif
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
@endsection