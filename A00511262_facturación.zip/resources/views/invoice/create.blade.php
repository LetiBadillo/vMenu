@extends('layouts.layout')
@section('content')
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Facturar</h1>
        <form class="form-inline">
            <input type="number" id="items" class="form-control mb-2 mr-sm-2 mb-sm-0" id="inlineFormInput">
            <button type="button" class="btn btn-primary" id="AddItems">Agregar items</button>    
        </form>
        
        <form class="form-inline" method="post" id="agenda" action="{{route('invoice.store')}}">
            {{ csrf_field() }}
            <br>
            <label for="client">Cliente</label>
            <select name="client_id" id="clients" required class="col-lg-12 form-control">
                                <option value="">Seleccionar cliente</option>
                        </select>
            <br>
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">-</th>
                    <th class="text-center">ITEM</th>
                    <th class="text-center">PRICE</th>
                    <th class="text-center">QUANTITY</th>
                    <th class="text-center">=</th>
                    </tr>
                </thead>
                <tbody id="hola">
                    
                    <tr>
                    <td><button type="button" class="btn btn-danger remove">Eliminar</button></td>
                    <td>
                        <select required name="product[]" id="products" class="item form-control">
                                <option value="">Seleccionar item</option>
                        </select>
                    </td>
                    <td>
                        <input readonly type="text" class="price form-control">
                    </td>
                    <td><input type="number" name="quantity[]" class="quantity form-control"></td>
                    <td><input readonly type="text" class="subtotal form-control"></td>
                    </tr>
                   
                
                </tbody>
            </table>

            

            <br>
            <input type="submit" class="btn btn-success" name="submit" value="Generar factura">
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="{{url('products')}}">Ver lista de facturas</a>
        </div>
    </div>
@endsection

@section('scripts')
<script>
    var products = '';
    $('#AddItems').click(function(e){
        var num = $('#items').val();
        var text = '';
        for(var i = 0; i < num; i++){
            text += '<tr>\
                    <td> <button type="button" class="btn btn-danger remove">Eliminar</button> </td>\
                    <td>\
                        <select name="product[]" id="products" class="item form-control">\
                                <option value="">Seleccionar item</option>\
                                '+products+'</select>\
                    </td>\
                    <td>\
                        <input readonly type="text" class="price form-control">\
                    </td>\
                    <td><input type="number" class="quantity form-control"></td>\
                    <td><input readonly type="text" class="subtotal form-control"></td>\
                    </tr>';
        }
        $('tbody').append(text);
        remove();    
        getPrice(); 
        getSubtotal();
    });

    remove();
    getPrice();
    getSubtotal();
    function remove(){
        $('.remove').click(function(){
            $(this).closest('tr').remove();
        });
    }

    function getPrice(){
        $('.item').on('change', function(){
            var o = $('option:selected', this).attr('data-price');
            console.log(o);
            $(this).closest('td').next('td').find('input').val(o);
        });
    }

    function getSubtotal(){
        $('.quantity').keyup(function(){
            var o = $(this).closest('tr').find('input').val().substring(1) * $(this).val();
            $(this).closest('td').next('td').find('.subtotal').val('$'+o);
        });
    }


    
    $.getJSON( "{{url('clients')}}?ws=all", function( data ) {
        var clients = '';
        for(var i = 0; i < data.length; i++){
            clients += '<option value="'+data[i].id+'">'+data[i].name+' '+data[i].last_name+'</option>';
            
        }
        $('#clients').append(clients);
    });
    $.getJSON( "{{url('products')}}?ws=all", function( data ) {
        for(var i = 0; i < data.length; i++){
            products += '<option data-price="$'+data[i].price+'" value="'+data[i].id+'">'+data[i].description+'</option>';
        }
        $('#products').append(products);
    });
</script>
@endsection