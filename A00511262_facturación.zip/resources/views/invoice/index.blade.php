@extends('layouts.layout')
@section('content')
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Facturas</h1>
            <br>
            <a class="btn btn-primary" href="{{route('invoice.create')}}"> + Nueva factura</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">ID</th>
                    <th class="text-center">Cliente</th>
                    <th class="text-center">Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($invoices))
                    @foreach($invoices as $invoice)
                    <tr>
                    <td> <a href="{{url('invoice')}}{{'/'.$invoice->id}}"> {{$invoice->id}} </a></td>
                    <td>{{$invoice->client->name}}</td>
                    <td>{{$invoice->created_at}}</td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay facturas registradas</td>
                    </tr>
                    @endif
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
@endsection