@extends('layouts.layout')
@section('content')
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Detalle</h1>
        <br>
        <p>Cliente: {{$invoice->client->name}}</p>
        <p>Fecha: {{$invoice->created_at}}</p>
        <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">SKU</th>                    
                    <th class="text-center">Producto</th>
                    <th class="text-center">Cantidad</th>
                    <th class="text-center">Precio</th>
                    <th class="text-center">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                @php $suma = 0; @endphp
                    @if($invoice)
                        @foreach($invoice->invoice_detail as $i)
                        <tr>
                        <td>{{ $i->product->sku}}</td>
                        <td>{{ $i->product->description}}</td>
                        <td>{{ $i->quantity}}</td>
                        <td>{{ $i->product->price}}</td>
                        <td>${{ $i->quantity * $i->product->price}}</td>
                        @php  $suma += $i->quantity * $i->product->price @endphp
                        </tr>
                        @endforeach
                        <tr>
                        <td colspan="4">Subotal:</td>
                        <td colspan="1">${{ $suma }}</td>
                        </tr>
                        <tr>
                        <td colspan="4">IVA:</td>
                        <td colspan="1">${{ $suma * 0.16 }}</td>
                        </tr>
                        <tr>
                        <td colspan="4">Total:</td>
                        <td colspan="1">${{ $suma + $suma * 0.16 }}</td>
                        </tr>
                    @else
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay productos registrados</td>
                    </tr>
                    @endif
                
                </tbody>
        </table>
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="{{url('invoice')}}">Facturas</a>
        </div>
    </div>
@endsection