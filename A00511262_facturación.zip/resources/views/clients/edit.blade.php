@extends('layouts.layout')
@section('content')
    <br><br>
    <div class="box text-center">
        <div class="border caption">
        <h1>Catálogo de clientes</h1>
        <form method="post" action="{{route('clients.update', ['id'=>$client->id])}}">
            {{ csrf_field() }}
            <input type="hidden" name="_method" value="PUT">
            <label for="name">Nombre:</label>
            <input class="form-control" required type="text" value="{{$client->name}}" name="name" id="">
            <label for="last_name">Apellidos:</label>
            <input class="form-control" required type="text" value="{{$client->last_name}}" name="last_name" id="">
            <label for="street">E-mail:</label>
            <div class="input-group">
				<span class="input-group-addon" id="MoneyAddon"><b>@</b></span>
				</span><input class="form-control" required type="email" value="{{$client->email}}" name="email" id="">
			</div>
            <label for="last_name">RFC:</label>
            <input class="form-control" required type="text" name="rfc" value="{{$client->rfc}}" id="">
            <label for="last_name">Dirección:</label>
            <input class="form-control" required type="text" name="address" value="{{$client->address}}" id="">
            <label for="last_name">Ciudad:</label>
            <input class="form-control" required type="text" name="city" value="{{$client->city}}" id="">
            <label for="last_name">CP:</label>
            <input class="form-control" required type="text" name="zipcode" value="{{$client->zipcode}}"id="">
            <label for="last_name">Teléfono:</label>
            <input class="form-control" required type="text" name="phone" value="{{$client->phone}}" id="">
            <br>
            <input type="submit" class="btn btn-success" name="submit" value="Guardar">
        </form>
        </div>
    </div>
    <div class="box text-center">
        <div class="caption">
            <a href="{{url('clients')}}">Ver lista de clientes</a>
        </div>
    </div>
@endsection