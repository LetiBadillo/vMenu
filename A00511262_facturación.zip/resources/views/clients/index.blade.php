@extends('layouts.layout')
@section('content')
    <br><br>
    
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
            <h1> Catálogo de clientes</h1>
            <br>
            <a class="btn btn-primary" href="{{route('clients.create')}}"> + Nuevo cliente</a>            
            <br>
            <br>
            
            <table class="table table-striped">
                <thead>
                    <tr>
                    <th class="text-center">Nombre</th>
                    <th class="text-center">Apellido</th>
                    <th class="text-center">E-mail</th>
                    <th class="text-center">RFC</th>
                    <th class="text-center">Dirección</th>
                    <th class="text-center">Ciudad</th>
                    <th class="text-center">CP</th>
                    <th class="text-center">Teléfono</th>
                    <th class="text-center" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($clients))
                    @foreach($clients as $client)
                    <tr>
                    <td>{{$client->name}}</td>
                    <td>{{$client->last_name}}</td>
                    <td>{{$client->email}}</td>
                    <td>{{$client->rfc}}</td>
                    <td>{{$client->address}}</td>
                    <td>{{$client->city}}</td>
                    <td>{{$client->zipcode}}</td>
                    <td>{{$client->phone}}</td>
                    <td><a href="{{route('clients.edit', ['id'=>$client['id']])}}" class="btn btn-warning">Edit</a></td>
                    <td>
                    <form action="{{route('clients.destroy', ['id'=>$client->id])}}" method="post">
                        {{ csrf_field() }}
                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="{{$client->id}}">
                        <button class="btn btn-danger" type="submit">Delete</button>
                    </form>
                    </td>
                    </tr>
                    @endforeach
                    @else
                    <tr>
                    <td class="text-center alert alert-danger" colspan="9">No hay clientes registrados</td>
                    </tr>
                    @endif
                
                </tbody>
        </table>
            </div>
        </div>
    </div>
    
@endsection