<?php echo $__env->make('partials.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
<h4 class="h2"><a class="nav-item" href="<?php echo e(url('patients')); ?>">Pacientes</a> / <?php echo e($patient->name); ?> <?php echo e($patient->last_name); ?></h4>
<div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a href="<?php echo e(route('consultations.create')); ?>?patient=<?php echo e($patient->id); ?>" class="btn btn-sm btn-outline-secondary">Realizar consulta &#10093</a>
            <a href="<?php echo e(route('patients.edit', ['id' => $patient->id])); ?>" class="btn ml-2 btn-sm btn-outline-primary">Editar &#10093</a>
            <form action="<?php echo e(route('patients.destroy', ['id'=>$patient->id])); ?>" class="form<?php echo e($patient->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="<?php echo e($patient->id); ?>">
                    </form>
                    <button class="btn btn-sm btn-outline-danger ml-2 deleteForm" data-form="form<?php echo e($patient->id); ?>" type="button">Eliminar &#10093</button>
          </div>
        </div>
</div>
    <?php echo $__env->make('partials.patient_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
    <h1 class="h2">Historial de consultas de <?php echo e($patient->name); ?></h1>
</div>
    <?php $consultations = $patient->consultation ?>
    <?php echo $__env->make('partials.consultations_index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    patient = <?php echo str_replace("'", "\'", json_encode($patient)); ?>;
    $('.paciente').addClass('active');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>