<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h4 class="h2"><a class="nav-item" href="<?php echo e(url('patients')); ?>">Pacientes</a> / <a href="<?php echo e(route('patients.show', ['id'=>$patient['id']])); ?>"><?php echo e($patient->name); ?> <?php echo e($patient->last_name); ?></a> / Editar</h4>
        <div class="btn-toolbar mb-2 mb-md-0">
          <div class="btn-group mr-2">
            <a href="<?php echo e(route('consultations.create')); ?>?patient=<?php echo e($patient->id); ?>" class="btn btn-sm btn-outline-secondary">Realizar consulta</a>
            <form action="<?php echo e(route('patients.destroy', ['id'=>$patient->id])); ?>" class="form<?php echo e($patient->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="<?php echo e($patient->id); ?>">
                    </form>
                    <button class="btn btn-sm btn-outline-danger ml-2 deleteForm" data-form="form<?php echo e($patient->id); ?>" type="button">Eliminar</button>
          </div>
        </div>
    </div>
    <form id="StorePatient">
    <?php echo e(csrf_field()); ?>

    <div style="display:none;" class="alert alert-success" role="alert">
    </div>
    <input type="hidden" name="_method" value="PUT">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label for="firstName">Nombres</label>
          <input type="text" class="form-control" id="firstName" value="<?php echo e($patient->name); ?>" name="name">
          <div class="name-feedback feedback">
            
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <label for="lastName">Apellidos</label>
          <input type="text" name="last_name" class="form-control" id="lastName" value="<?php echo e($patient->last_name); ?>" placeholder="" value="">
          <div class="last_name-feedback feedback">
            
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label for="email">Email <span class="text-muted">(opcional)</span></label>
          <input type="email" class="form-control" name="email" id="email" value="<?php echo e($patient->email); ?>" placeholder="name@example.com">
          <div class="email-feedback feedback">
          </div>
      </div>
      <div class="col-md-3 mb-3">
        <label for="age">Edad</label>
        <input type="number" class="form-control" value="<?php echo e($patient->age); ?>" id="age" name="age">
        <div class="age-feedback feedback">
        </div>
      </div>
      <div class="col-md-3 mb-3">
        <label for="weight">Peso</label>
        <input type="text" class="form-control" value="<?php echo e($patient->weight); ?>" name="weight" id="weight">
        <div class="weight-feedback feedback">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 mb-3">
        <label for="country">Tipo de Sangre</label>
        <select class="custom-select d-block w-100" id="bloodtype" name="bloodtype">
          <option value="">Elige una opción...</option>
          <option value="1">A+</option>
          <option value="2">A-</option>
          <option value="3">B+</option>
          <option value="4">B-</option>
          <option value="5">O+</option>
          <option value="6">O-</option>
          <option value="7">AB+</option>
          <option value="8">AB-</option>
        </select>
        <div class="bloodtype-feedback feedback">
        </div>
      </div>
      <div class="col-md-9 mb-3">
        <label for="zip">Alergias</label>
        <input type="text" class="form-control" value="<?php echo e($patient->alergies); ?>" name="alergies">
        <div class="alergies-feedback feedback">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 mb-3">
        <label for="chronic">Padecimientos crónicos</label>
        <input type="text" class="form-control" name="chronic" value="<?php echo e($patient->chronic); ?>" id="chronic">
        <div class="chronic-feedback feedback">
        </div>
      </div>
    </div>
    <hr class="mb-4">
    <h4 class="mb-3">Autoriza donar sus órganos</h4>
    <div class="d-block my-3">
      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" name="donate" class="form-check-input"  <?php if($patient->donate == 1) echo "checked"; ?> value="1" checked>
          Sí
        </label>
      </div>
      <div class="form-check">
        <label class="form-check-label">
          <input type="radio" name="donate"  <?php if($patient->donate == 0) echo "checked"; ?> class="form-check-input" value="0">
          No
        </label>
      </div>
    </div>
    <hr class="mb-4">
    <button class="btn btn-lg btn-block btn-primary" type="submit"> Guardar </button>
  </form>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    patient = <?php echo str_replace("'", "\'", json_encode($patient)); ?>;
    $('.paciente').addClass('active');
    $('#bloodtype').val(<?php echo e($patient->bloodtype); ?>);
    $('#StorePatient').on('submit', function(e){
      e.preventDefault();
      var data = new FormData($(this)[0]);
      $.ajax({
				url:"<?php echo e(route('patients.update', ['id'=>$patient->id])); ?>",
				type:'POST',
        data: data,
				contentType:false,
				processData:false,
				success : function(data){
					$('.alert').text(data).show();
				},
				error:function(data){						
					$.each(data.responseJSON, function(k,v){
						console.log(k);
            console.log(v);
					});
				}

			});
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>