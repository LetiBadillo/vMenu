<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
        <h4 class="h2">Pacientes /</h4>
   </div>
   <input class="form-control search form-control-dark w-100" type="text" placeholder="Buscar" aria-label="Buscar">
   <br>
      <table class="table table-striped results">
          <thead class="thead-dark">
                    <tr>
                    <th>Paciente</th>
                    <th class="text-center">Edad</th>
                    <th class="text-center" colspan="4"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($patients)): ?>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($patient->name); ?> <?php echo e($patient->last_name); ?></td>
                    <td class="text-center"><?php echo e($patient->age); ?></td>
                    <td class="text-center"><a href="<?php echo e(route('consultations.create')); ?>?patient=<?php echo e($patient->id); ?>" class="btn btn-outline-secondary">Realizar consulta médica &#10093</a></td>
                    <td class="text-center"><a href="<?php echo e(route('patients.show', ['id'=>$patient['id']])); ?>" class="btn btn-info">Ver detalle &#10093</a></td>
                    <td class="text-center"><a href="<?php echo e(route('patients.edit', ['id'=>$patient['id']])); ?>" class="btn btn-primary">Editar &#10093</a></td>
                    <td class="text-center">
                    <form action="<?php echo e(route('patients.destroy', ['id'=>$patient->id])); ?>" class="form<?php echo e($patient->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="DELETE">
                        <input name="id" type="hidden" value="<?php echo e($patient->id); ?>">
                        
                    </form>
                    <button class="btn btn-danger deleteForm" data-form="form<?php echo e($patient->id); ?>" type="button">Eliminar &#10093</button>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="warning no-result">
                      <td class="text-center alert alert-danger" colspan="5">No hay pacientes registrados</td>
                    </tr>
                    <?php else: ?>
                    <tr>
                    <td class="text-center alert alert-danger" colspan="5">No hay pacientes registrados</td>
                    </tr>
                    <?php endif; ?>
                
                </tbody>
        </table>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.paciente').addClass('active');
    $('.paciente_index').wrap('<b></b>');
    $('#collapsePacientes').addClass('show');
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>