<div class="card mb-4 box-shadow">
          <div class="card-header">
          <h4 class="my-0 font-weight-normal">Detalles del paciente</h4>
          </div>
          <div class="card-body">
            <h3 class="card-title pricing-card-title"><?php echo e($patient->name); ?> <?php echo e($patient->last_name); ?></h3>
            <ul class="list-unstyled mb-4">
              <li><?php echo e($patient->age); ?> años</li>
              <li><?php echo e($patient->weight); ?> kg</li>
              <li><strong>Tipo de sangre: </strong><?php echo e($patient->bloodName); ?></li>
              <li><strong>Alergias:</strong> <?php echo e($patient->alergies); ?></li>
              <li><strong>Enfermedades crónicas:</strong> <?php echo e($patient->chronic); ?></li>
              <?php if($patient->donate == 1): ?>
              <li><strong>Dona sus órganos</strong></li>
              <?php endif; ?>
              <li><?php echo e($patient->email); ?></li>
            </ul>
          </div>
        </div>