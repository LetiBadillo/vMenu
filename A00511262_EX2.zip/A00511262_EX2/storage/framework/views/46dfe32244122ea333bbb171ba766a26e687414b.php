<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br>
    <div class="text-center align-middle" style="height: 100vH !important;">
        <h1>Hospital APD</h1>
        <br><br>
        <img class="mb-4 img-fluid" src="<?php echo e(url('images/welcome.gif')); ?>">
        <br><br>
        <p><?php echo e(count(App\Models\Patient::all())); ?> pacientes registrados</p>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.inicio').addClass('active');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>