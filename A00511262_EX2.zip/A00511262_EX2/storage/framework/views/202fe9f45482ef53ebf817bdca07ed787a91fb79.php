  <input class="form-control search form-control-dark w-100" type="text" placeholder="Buscar" aria-label="Buscar">
  <br>
  <table class="table results table-striped">
      <thead class="thead-dark">
                <tr>
                <th class="text-center">Paciente</th>
                <th class="text-center">Fecha</th>
                <th class="text-center" colspan="1"></th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($consultations)): ?>
                <?php $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($consultation->patient->name); ?> <?php echo e($consultation->patient->last_name); ?></td>
                <td class="text-center"><?php echo e($consultation->created_at); ?></td>
                <td class="text-center">
                    <a class="nav-link" data-toggle="collapse" href="#c-<?php echo e($consultation->id); ?>" role="button" aria-expanded="false" aria-controls="collapseExample">
                            Ver más
                            <span class="dropdown-toggle"></span>
                        </a>
                  </td>
                </tr>
                <tr class="collapse detail" id="c-<?php echo e($consultation->id); ?>">
                <td>Descripción: 
                    <p><?php echo e($consultation->description); ?><p></td>
                <td>Diagnósitico: 
                    <p><?php echo e($consultation->diagnosed); ?></p>
                </td>
                <td class="text-center"><a href="<?php echo e(route('consultations.show', ['id'=>$consultation['id']])); ?>" class="btn btn-outline-secondary">Ver detalle completo &#10093</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="warning no-result">
                    <td class="text-center alert alert-danger" colspan="5">No hay consultas registradas</td>
                </tr>
                <?php else: ?>
                <tr>
                <td class="text-center alert alert-danger" colspan="5">No hay consultas registradas</td>
                </tr>
                <?php endif; ?>
            
            </tbody>
    </table>